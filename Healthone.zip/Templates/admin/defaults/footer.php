<footer >
    <p class="clearfix pb-3 text-primary text-center">2022 Health one&reg;</p>
</footer>
